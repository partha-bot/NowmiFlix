document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  const clearSearch = document.getElementById("clearSearch");
  const categoryButtons = [...document.querySelectorAll(".category")];
  const groups = [...document.querySelectorAll(".site-group")];
  const resultText = document.getElementById("resultText");
  let selectedCategory = "all";

  // Count the real website links inside each Explore Websites category.
  groups.forEach((group) => {
    const cards = [...group.querySelectorAll(".website-card")];
    const count = group.querySelector(".group-count[data-count]");
    if (count) count.textContent = String(cards.length);

    const header = group.querySelector(".group-header");
    const panel = group.querySelector(".website-grid");
    if (header && panel) {
      header.setAttribute("aria-expanded", String(!panel.hidden));
      header.addEventListener("click", () => {
        const open = header.getAttribute("aria-expanded") !== "true";
        header.setAttribute("aria-expanded", String(open));
        panel.hidden = !open;
        group.classList.toggle("expanded", open);
      });
    }
  });

  function filterSites() {
    const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
    let totalVisible = 0;
    let visibleGroups = 0;

    groups.forEach((group) => {
      const category = (group.dataset.category || "").toLowerCase();
      const categoryMatches = selectedCategory === "all" || category === selectedCategory;
      const cards = [...group.querySelectorAll(".website-card")];
      const header = group.querySelector(".group-header");
      const panel = group.querySelector(".website-grid");
      let matchingCards = 0;

      cards.forEach((card) => {
        const searchable = `${card.dataset.name || ""} ${card.textContent || ""} ${card.href || ""}`.toLowerCase();
        const matches = categoryMatches && searchable.includes(query);
        card.hidden = !matches;
        if (matches) matchingCards++;
      });

      const showGroup = categoryMatches && (query ? matchingCards > 0 : true);
      group.hidden = !showGroup;
      if (showGroup) visibleGroups++;
      totalVisible += matchingCards;

      if (header && panel) {
        // Search results open automatically; category filtering keeps sections collapsed/open as selected by user.
        if (query && showGroup) {
          header.setAttribute("aria-expanded", "true");
          panel.hidden = false;
          group.classList.add("expanded");
        } else if (query && !showGroup) {
          header.setAttribute("aria-expanded", "false");
          panel.hidden = true;
          group.classList.remove("expanded");
        }
      }
    });

    if (resultText) {
      resultText.textContent = query
        ? `${totalVisible} website(s) found`
        : `${totalVisible} websites available across ${visibleGroups} categories`;
    }
  }

  categoryButtons.forEach((button) => {
    button.addEventListener("click", () => {
      categoryButtons.forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      selectedCategory = (button.dataset.category || "all").toLowerCase();
      filterSites();
    });
  });

  if (searchInput) searchInput.addEventListener("input", filterSites);
  if (clearSearch && searchInput) {
    clearSearch.addEventListener("click", () => {
      searchInput.value = "";
      filterSites();
      searchInput.focus();
    });
  }

  filterSites();

  // Register the PWA service worker once (the duplicate registration was removed from index.html).
  if ("serviceWorker" in navigator && location.protocol === "https:") {
    navigator.serviceWorker.register("./service-worker.js").catch((error) => {
      console.error("NowmiFlix service worker registration failed:", error);
    });
  }
});
