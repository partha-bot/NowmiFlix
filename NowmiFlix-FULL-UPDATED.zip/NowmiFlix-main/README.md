# NowmiFlix

Static entertainment-directory website.

## Files
- `index.html` — page structure and website directory
- `style.css` — responsive UI
- `script.js` — category filtering, search, counts, expand/collapse, logo fallbacks
- `manifest.webmanifest` + `service-worker.js` — PWA support
- `nowmiflix-192.png` / `nowmiflix-512.png` — app icons

## GitHub Pages
Upload the contents of `NowmiFlix-main` to the repository root, or keep the existing repository folder structure if your deployment already expects it.
