document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  const clearSearch = document.getElementById("clearSearch");
  const emptyMessage = document.getElementById("emptyMessage");
  const categoryButtons = [...document.querySelectorAll(".category")];
  const groups = [...document.querySelectorAll(".site-group")];
  const resultText = document.getElementById("resultText");
  let selectedCategory = "all";

  // Keep the category counts tied to the actual website cards in the HTML.
  groups.forEach((group) => {
    const cards = [...group.querySelectorAll(".website-card")];
    const count = group.querySelector("[data-count]");
    if (count) count.textContent = String(cards.length);

    const header = group.querySelector(".group-header");
    const panel = group.querySelector(".website-grid");

    if (header && panel) {
      const setExpanded = (open) => {
        header.setAttribute("aria-expanded", String(open));
        panel.hidden = !open;
        group.classList.toggle("expanded", open);
      };

      setExpanded(false);
      header.addEventListener("click", () => {
        setExpanded(header.getAttribute("aria-expanded") !== "true");
      });

      group._setExpanded = setExpanded;
    }
  });

  // Website logo fallback: if a remote favicon is unavailable, show initials.
  document.querySelectorAll(".website-logo").forEach((img) => {
    const fallback = img.parentElement?.querySelector(".website-logo-fallback");
    if (!fallback) return;

    const showFallback = () => {
      img.style.display = "none";
      fallback.style.display = "grid";
    };

    img.addEventListener("error", showFallback, { once: true });
    if (img.complete && img.naturalWidth === 0) showFallback();
  });

  function updateClearButton() {
    if (!clearSearch || !searchInput) return;
    clearSearch.hidden = searchInput.value.trim() === "";
  }

  function filterSites() {
    const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
    let totalVisible = 0;
    let visibleGroups = 0;

    groups.forEach((group) => {
      const category = (group.dataset.category || "").toLowerCase();
      const categoryMatches = selectedCategory === "all" || category === selectedCategory;
      const cards = [...group.querySelectorAll(".website-card")];
      const header = group.querySelector(".group-header");
      const panel = group.querySelector(".website-grid");
      let matchingCards = 0;

      cards.forEach((card) => {
        const searchable = `${card.dataset.name || ""} ${card.textContent || ""} ${card.getAttribute("href") || ""}`.toLowerCase();
        const matches = categoryMatches && searchable.includes(query);
        card.hidden = !matches;
        if (matches) matchingCards++;
      });

      const showGroup = categoryMatches && (query ? matchingCards > 0 : true);
      group.hidden = !showGroup;
      if (showGroup) visibleGroups++;
      totalVisible += matchingCards;

      if (header && panel && group._setExpanded) {
        const shouldOpen = query ? showGroup : selectedCategory === "all" ? showGroup : categoryMatches && showGroup;
        group._setExpanded(shouldOpen);
      }
    });

    if (resultText) {
      resultText.textContent = query
        ? `${totalVisible} website${totalVisible === 1 ? "" : "s"} found`
        : `${totalVisible} website${totalVisible === 1 ? "" : "s"} available across ${visibleGroups} categor${visibleGroups === 1 ? "y" : "ies"}`;
    }

    if (emptyMessage) {
      emptyMessage.hidden = !(query && totalVisible === 0);
    }

    updateClearButton();
  }

  categoryButtons.forEach((button) => {
    button.addEventListener("click", () => {
      categoryButtons.forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      selectedCategory = (button.dataset.category || "all").toLowerCase();
      filterSites();

      document.getElementById("sites")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  if (searchInput) searchInput.addEventListener("input", filterSites);

  if (clearSearch && searchInput) {
    clearSearch.addEventListener("click", () => {
      searchInput.value = "";
      filterSites();
      searchInput.focus();
    });
  }

  filterSites();

  if ("serviceWorker" in navigator && location.protocol === "https:") {
    navigator.serviceWorker.register("./service-worker.js").catch((error) => {
      console.error("NowmiFlix service worker registration failed:", error);
    });
  }
});
